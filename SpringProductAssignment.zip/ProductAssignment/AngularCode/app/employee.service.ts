import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private baseUrl =  "http://localhost:8022/employee/isValid";
  myUrl : string;
  dataInEmployeeService: string;
  error : string;
  constructor(private http: HttpClient) { }

  isValidUser(): Observable<any>{
    this.myUrl = this.baseUrl + "?UserId=Test123&Password=admin";
    return this.http.get(this.myUrl,{responseType:'text'});
  }
}
