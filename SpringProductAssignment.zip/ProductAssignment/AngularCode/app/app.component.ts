import { Component } from '@angular/core';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(private employeeService: EmployeeService){}
  
  title = 'AngularSpring';
  dataString :string;
  errorMsg: string;
  isValidUserData: any;
  onSubmit(){
    this.employeeService.isValidUser().subscribe(
      data=>{
        this.dataString = data;
        alert(data);
        console.log(this.dataString);
      }
    );
  }

}
