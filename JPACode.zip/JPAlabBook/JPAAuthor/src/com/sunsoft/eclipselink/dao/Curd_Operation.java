package com.sunsoft.eclipselink.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.sunsoft.eclipselink.bean.AuthorJPA1;



public class Curd_Operation {
	static EntityManagerFactory emfactory=Persistence.createEntityManagerFactory("Eclipselink_JPA");
	 static EntityManager entitymanager=emfactory.createEntityManager();
	  
		public static void main(String[] args) {
		    Curd_Operation curdObj=new Curd_Operation();

		    AuthorJPA1 a=new AuthorJPA1();
			a.setAuthorid(101);
			a.setFirstName("Raj");
			a.setMiddleName("Kumar");
			a.setLastName("Shukla");
			a.setPhoneNo("9034567898");
			
			curdObj.InsertIntoAuthorDB(a);
			
			AuthorJPA1 auth = curdObj.getauthorDetails(101);
			System.out.println("Author id"+ auth.getAuthorid());
			System.out.println("Author Name : "+auth.getFirstName()+" "+auth.getMiddleName()+" "+auth.getLastName());
			System.out.println("Phone Number : "+auth.getPhoneNo());
			curdObj.UpdateAuthor(101,"2345898678");
			curdObj.DeleteAuthor(101);
		    System.out.println("record deleted successfully");
		}
			public void DeleteAuthor(int id)
			{
				entitymanager.getTransaction().begin();
				AuthorJPA1 au=entitymanager.find(AuthorJPA1.class, id);
				entitymanager.remove(au);
				entitymanager.getTransaction().commit();
			}
				
			
			public void UpdateAuthor(int id, String phoneNo)
			{
				  entitymanager.getTransaction().begin();
				  AuthorJPA1 au=entitymanager.find(AuthorJPA1.class, id);
				  au.setPhoneNo(phoneNo);
				  entitymanager.getTransaction().commit();
			}
			 
			public void InsertIntoAuthorDB(AuthorJPA1 auth)
			{
				entitymanager.getTransaction().begin();
				entitymanager.persist(auth);
				entitymanager.getTransaction().commit();
			}
			
			public AuthorJPA1 getauthorDetails(int id) 
			{
				AuthorJPA1 au =entitymanager.find(AuthorJPA1.class, id);
				return au;
			}
			
}
