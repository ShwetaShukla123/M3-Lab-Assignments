package com.sunsoft.eclipselink.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class AuthorJPA1 {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int authorid;
	private String firstName;
	private String middleName;
	private String lastName;
	private String phoneNo;
	
	public AuthorJPA1(int authorid,String firstName,String middleName,String lastName, String phoneNo)
	{
		super();
		this.authorid=authorid;
		this.firstName=firstName;
		this.middleName=middleName;
		this.lastName=lastName;
		this.phoneNo=phoneNo;
		
	}
     public AuthorJPA1()
    {
	 super();
    }
	public int getAuthorid() {
		return authorid;
	}
	public void setAuthorid(int authorid) {
		this.authorid = authorid;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	@Override
	public String toString()
	{
		return "Author[authorid="+authorid+", firstname="+firstName+", middlename="+middleName+", lastname=" +lastName+", phoneno="+phoneNo +"]";
	}

}
