package com.author.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.author.bean.Book3;

public class AuthorCurd {

	static EntityManagerFactory emfactory= Persistence.createEntityManagerFactory("Eclipselink_JPA");
	static EntityManager entityManager= emfactory.createEntityManager();
	
	public List<Book3> getAllBooks(){
		Query bookQuery = entityManager.createNamedQuery("book3.findAll");
		List<Book3> books = bookQuery.getResultList();
		return books;
	}
	
	public List<Book3> getBooksByAuthorName(String name){
		 Query query = entityManager.createQuery( "select b from book3 b where b.isbn in (select ba.book_isbn from bookauthor3 ba where ba.author_id =(select a.id from author3 a where a.name=:name))");
		 query.setParameter("name", name);
		 List<Book3> list=(List<Book3>)query.getResultList();
	     return list;
	}
	
	public List<Book3> getBooksInRange(){
		 Query query = entityManager.createQuery( "Select b from book3 b  where b.price Between 500 and 1000" );
	      
	      List<Book3> list=(List<Book3>)query.getResultList( );
	      return list;
	}
	
	public String getAuthorByBookId(int isbn){
		Query query = entityManager.createQuery( "Select a.name from author3 a  where a.id=(select ba.author_id from bookauthor3 ba where ba.book_isbn="+isbn+")");
		String authName = (String) query.getSingleResult();
		return authName;
	}
}