package com.sunsoft.eclipselink.DAO;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.sunsoft.eclipselink.bean.EmployeeJPA;

public class CURD_Service {

		static EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("Eclipselink_JPA");
		static EntityManager entityManager = emfactory.createEntityManager();
		
		public static void main(String args[]){
			CURD_Service curdServiceObj = new CURD_Service();
			
			EmployeeJPA emp1 = new EmployeeJPA();
			emp1.setEid(1200);
			emp1.setDeg("Technical Manager");
			emp1.setEname("Hari");
			emp1.setSalary(60000);
			curdServiceObj.insertIntoEmployeeDB(emp1);
			
			
			EmployeeJPA emp2 = new EmployeeJPA();
			emp2.setEid(1201);
			emp2.setDeg("Technical Manager");
			emp2.setEname("Shiva");
			emp2.setSalary(70000);
			curdServiceObj.insertIntoEmployeeDB(emp2);
			
			EmployeeJPA emp = curdServiceObj.getEmployeeDetails(1200);
			System.out.println("Employee id : "+emp.getEid());
			System.out.println("Employee name : "+emp.getEname());
			System.out.println("Employee salary : "+emp.getSalary());
			System.out.println("Employee designation : "+emp.getDeg());
		}
		
		void insertIntoEmployeeDB(EmployeeJPA obj){
			entityManager.getTransaction().begin();
			entityManager.persist(obj);
			entityManager.getTransaction().commit();
		}
		
		void updateEmployee(int id, double salary){
			entityManager.getTransaction().begin();
			EmployeeJPA emp = entityManager.find(EmployeeJPA.class, id);
			emp.setSalary(salary);
			entityManager.getTransaction().commit();
		}
		
		EmployeeJPA getEmployeeDetails(int id){
			EmployeeJPA emp = entityManager.find(EmployeeJPA.class, id);
			return emp;
		}
}