package SpringAngular.Product.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import SpringAngular.Product.entity.Product;
import SpringAngular.Product.repository.IProductRepository;

@Service
public class ProductServiceImpl implements Product_Service {
	
	@Autowired
	private IProductRepository productRepository;

	@Override
	@Transactional
	public boolean saveProduct(Product product) {
		boolean status=false;
		try {
			productRepository.save(product);
			status = true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public List<Product> getProducts() {
		return productRepository.findAll();
	}

}
