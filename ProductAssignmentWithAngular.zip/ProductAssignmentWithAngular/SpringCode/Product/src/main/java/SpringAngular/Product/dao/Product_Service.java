package SpringAngular.Product.dao;

import java.util.List;

import SpringAngular.Product.entity.Product;

public interface Product_Service {
	 public boolean saveProduct(Product product);  
	 public List<Product> getProducts();
}
