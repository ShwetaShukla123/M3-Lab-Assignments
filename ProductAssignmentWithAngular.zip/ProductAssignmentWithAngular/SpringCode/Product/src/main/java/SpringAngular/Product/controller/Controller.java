package SpringAngular.Product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import SpringAngular.Product.dao.Product_Service;
import SpringAngular.Product.entity.Product;

@RestController
@CrossOrigin(origins="http://localhost:4200")  
@RequestMapping(value="/api")  
public class Controller {
	
	@Autowired  
    private Product_Service productservice; 
	
	@PostMapping("save-product")  
    public boolean saveProduct(@RequestBody Product product) {  
         return productservice.saveProduct(product);  
          
    } 
	
	@GetMapping("product-list")  
    public List<Product> allproducts() {  
         return productservice.getProducts();  
          
    }
	
}
