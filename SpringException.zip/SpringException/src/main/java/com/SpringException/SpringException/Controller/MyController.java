package com.SpringException.SpringException.Controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.SpringException.SpringException.Exception.InvalidProductIdException;
import com.SpringException.SpringException.Exception.InvalidProductNameException;

@RestController
public class MyController {
	
	@GetMapping(path="/isValid", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> index(@RequestParam("ProductId") int ProductId,
			@RequestParam("name") String name)throws InvalidProductIdException, InvalidProductNameException{
		String strValidProduct = new String();
		if(ProductId==0)
			throw new InvalidProductIdException("EXCEPTION: Invalid Product");
		else
			strValidProduct = "Valid Product";
		System.out.println("Name Value is: "+name);
		if(name.equals("")) {
			throw new InvalidProductNameException("EXCEPTION: Invalid Product Name");
		}
		return new ResponseEntity<>(strValidProduct, HttpStatus.OK);
	}
//	@ExceptionHandler(InvalidProductNameException.class)
//	public ResponseEntity<String> handleException(Exception ex){
//		return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
//	}
}