package com.SpringException.SpringException.Exception;

public class InvalidProductIdException extends Exception{
	public InvalidProductIdException(String str) {
		super(str);
	}
}