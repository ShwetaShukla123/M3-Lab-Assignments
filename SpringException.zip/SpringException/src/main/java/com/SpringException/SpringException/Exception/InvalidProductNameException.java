package com.SpringException.SpringException.Exception;

public class InvalidProductNameException extends Exception{
	public InvalidProductNameException(String str) {
		super(str);
	}
}
