package com.sunsoft.controller;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.sunsoft.entity.Trainee;
import com.sunsoft.service.ITraineeService;

@Controller
@RequestMapping("/Trainee")
public class TraineeController {
	
	private static final Logger LOG = LoggerFactory.getLogger(TraineeController.class);
	
	@Autowired
	private ITraineeService traineeService;
	
	@PostMapping("/loginValidate")
	 public ModelAndView validate(HttpServletRequest req, HttpServletResponse res){
		String name=req.getParameter("name");
		String pass=req.getParameter("pass");
		if(name.equalsIgnoreCase("Shweta") && pass.equals("admin"))
			return new ModelAndView("Operations-list");
		else{
			String message="<h4>Invalid username or password!</h4>";
			return new ModelAndView("errorPage", "message", message);
		}
	}
	
	@GetMapping("/list")
	public String listCustomer(Model theModel)
	{
		List<Trainee> thetrainees = traineeService.getTrainees();
		theModel.addAttribute("trainees", thetrainees);
		System.out.println("List of Data : "+thetrainees);
		return "list-trainee";		
	}
	
	@GetMapping("/operation")
	public String listOperation(){
		return "Operations-list";
	}
	
	@GetMapping("/add")
	public String addTrainee(Model theModel)
	{
		Trainee trainee = new Trainee();
		theModel.addAttribute("trainee", trainee);
		return "Trainee-form";		
	}
	
	@PostMapping("/saveTrainee")
	public String saveCustomer(@ModelAttribute("trainee") Trainee theTrainee)
	{
		traineeService.saveTrainee(theTrainee);
		return "redirect:/Trainee/operation";
	}
	
	@GetMapping("/update")
	public String modify(){
		return "modify";
	}
	
	@RequestMapping("/updateForm")
	public String showFormForUpdate(HttpServletRequest req, Model theModel){
		int theId = Integer.parseInt(req.getParameter("id"));
		Optional<Trainee> theTrainee = traineeService.getTrainee(theId);
		if(theTrainee.isPresent()){
			theModel.addAttribute("trainee", theTrainee.get());
		}
		return "Update-form";
	}
	
	@GetMapping("/delete")
	public String delete(){
		return "delete";
	}
	
	@PostMapping("/deleteForm")
	public String deleteCustomer(HttpServletRequest req){
		int theId = Integer.parseInt(req.getParameter("id"));
		traineeService.deleteTrainee(theId);
		return "Operations-list";
	}
	
	@GetMapping("/retrieve")
	public String findForm(){
		return "find";
	}
	
	@PostMapping("/retrieveForm")
	public String retrieveCustomer(HttpServletRequest req, Model theModel){
		int theId = Integer.parseInt(req.getParameter("id"));
		Optional<Trainee> trainee = traineeService.getTrainee(theId);
		if(trainee.isPresent()){
			theModel.addAttribute("trainee", trainee.get());
		}
		return "displayOneTrainee";
	}
}