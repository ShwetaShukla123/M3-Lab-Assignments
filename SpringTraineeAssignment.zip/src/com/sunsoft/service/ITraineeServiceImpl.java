package com.sunsoft.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunsoft.entity.Trainee;
import com.sunsoft.repository.ITraineeRepository;

@Service
public class ITraineeServiceImpl implements ITraineeService{

	@Autowired
	private ITraineeRepository traineeRepository;
	
	@Override
	public List<Trainee> getTrainees() {
		return traineeRepository.findAll();
	}
	
	@Override
	public Optional<Trainee> getTrainee(int theId) {
		Optional<Trainee> traineeObj = traineeRepository.findById(theId);
		return traineeObj;
	}

	@Override
	@Transactional
	public void deleteTrainee(int theId) {
		traineeRepository.deleteById(theId);
	}
	
	@Override
	public void saveTrainee(Trainee theTrainee) {
		traineeRepository.save(theTrainee);
	}
}
