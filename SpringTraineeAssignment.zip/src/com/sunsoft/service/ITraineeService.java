package com.sunsoft.service;

import java.util.List;
import java.util.Optional;

import com.sunsoft.entity.Trainee;

public interface ITraineeService {
	public List <Trainee> getTrainees();
	public Optional <Trainee> getTrainee(int theId);
	public void deleteTrainee(int theId);
	public void saveTrainee(Trainee theTrainee);

}
